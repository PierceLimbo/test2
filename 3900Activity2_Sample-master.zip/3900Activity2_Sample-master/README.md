Sample repository for static, HTML 2-page assignment.
2 linked HTML files include: index.html and boomer.html with 3 images.
And 1 css file
